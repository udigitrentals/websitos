﻿import esbuild from "esbuild";
await esbuild.build({ entryPoints:["v2/core/pipeline.ts","v2/server/index.ts"], outdir:"build", bundle:true, platform:"node", format:"esm", target:["node18"], sourcemap:true });
