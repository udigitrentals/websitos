﻿import express from "express"; import path from "path"; import bodyParser from "body-parser"; import helmet from "helmet"; import cors from "cors"; import morgan from "morgan";
const app=express(); app.use(cors()); app.use(morgan("tiny")); app.use(bodyParser.json()); app.use(helmet());
app.use("/assets", express.static(path.resolve("v2/public/assets")));
app.use(express.static(path.resolve("dist")));
app.post("/api/leads",(req,res)=>{ const {email,consent}=req.body||{}; if(!email||!consent) return res.status(400).json({ok:false}); res.json({ok:true}); });
app.get("/", (_req,res)=>res.sendFile(path.resolve("dist/page.html")));
const port=process.env.PORT||3000; app.listen(port, ()=>console.log("listening on :"+port));
