﻿import type { Ctx } from "../render.js";
type M = { flag:string; apply:(html:string, ctx:Ctx)=>Promise<string> };
import lead from "./lead.js"; import ga4 from "./ga4.js"; import utm from "./utm_persist.js"; import consent from "./consent_mode.js"; import seo from "./seo_jsonld.js";
const modules: M[] = [lead, ga4, utm, consent, seo]; export default modules;
