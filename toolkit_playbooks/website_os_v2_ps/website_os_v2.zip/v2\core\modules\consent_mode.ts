﻿import { partial } from "../render.js";
export default { flag:"consent_mode", async apply(html:string){ return html.replace("</body>", `${partial("consent.html")}</body>`); } };
